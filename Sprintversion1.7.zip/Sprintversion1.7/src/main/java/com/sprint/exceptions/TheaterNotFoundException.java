package com.sprint.exceptions;

public class TheaterNotFoundException extends RuntimeException {

	public TheaterNotFoundException(String msg) {
		super(msg);
	}
}

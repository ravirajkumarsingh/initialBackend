package com.sprint.exceptions;

public class ShowNotFound extends RuntimeException{

	public ShowNotFound(String msg) {
		super(msg);
	}
}

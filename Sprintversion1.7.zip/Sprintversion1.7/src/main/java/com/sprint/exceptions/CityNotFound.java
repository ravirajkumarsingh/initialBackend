package com.sprint.exceptions;

public class CityNotFound extends RuntimeException{

	public CityNotFound(String msg) {
		super(msg);
	}
}

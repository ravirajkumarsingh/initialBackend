package com.sprint.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sprint.entity.Booking;
import com.sprint.repository.BookingRepository;

@Repository
public class BookingDao {

	@Autowired
	BookingRepository bookingRepository;
	
	public Booking addBooking(Booking book) {
		return bookingRepository.save(book);
	}
	
	public String cancelBooking(Booking book) {
		bookingRepository.deleteById(book.getShow_Id());
		return "Booking is Cancelled";
	}
	
	public Optional<Booking> findById(long id){
		return bookingRepository.findById(id);
	}
	
	public long bookingCost(long bookingId) {

		return bookingRepository.getOne(bookingId).getTotalSeat()*200;

		
	}
	
	public List<Booking> getBooking(){
		return bookingRepository.findAll();
	}

	public Booking findOne(long id) {
		// TODO Auto-generated method stub
		return bookingRepository.findById(id).get();
	}

	public Booking getOne(long id) {
		// TODO Auto-generated method stub
		return null;
	}
}

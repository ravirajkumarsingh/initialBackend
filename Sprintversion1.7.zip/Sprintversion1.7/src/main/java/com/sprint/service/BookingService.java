package com.sprint.service;

import java.util.List;
import java.util.Optional;

import com.sprint.entity.Booking;

public interface BookingService {

	public Booking addBooking(Booking book);
	public String cancelBooking(Booking book);
	public long bookingCost(long bookingId);
	public List<Booking> getBooking();
	public Booking findOne(long id);
	public Booking getAvailableSeat(long id);
}

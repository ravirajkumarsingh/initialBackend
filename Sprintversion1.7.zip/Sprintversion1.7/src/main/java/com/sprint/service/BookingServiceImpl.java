package com.sprint.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.dao.BookingDao;
import com.sprint.entity.Booking;
import com.sprint.entity.City;
import com.sprint.exceptions.BookingNotFound;
import com.sprint.exceptions.CityNotFound;

@Service
public class BookingServiceImpl implements BookingService{

	@Autowired
	BookingDao bookingDao;
	
	@Override
	public Booking addBooking(Booking book) {
		// TODO Auto-generated method stub
		return bookingDao.addBooking(book);
	}

	@Override
	public String cancelBooking(Booking book) {
		// TODO Auto-generated method stub
		Optional<Booking> b = bookingDao.findById(book.getShow_Id());
		if(!b.isPresent()) {
			throw new BookingNotFound("Booking Not Found For the given Id");
		}
		return bookingDao.cancelBooking(book);
	}
	@Override
	public long bookingCost(long bookingId) {
		// TODO Auto-generated method stub
		return bookingDao.bookingCost(bookingId);
	}

	@Override
	public List<Booking> getBooking() {
		// TODO Auto-generated method stub
		return bookingDao.getBooking();
	}

	@Override
	public Booking findOne(long id) {
		// TODO Auto-generated method stub
		return bookingDao.findOne(id);
	}

	@Override
	public Booking getAvailableSeat(long id) {
		// TODO Auto-generated method stub
		return bookingDao.getOne(id);
	}

}
